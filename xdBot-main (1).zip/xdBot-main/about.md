# xdBot

<cl>xdBot</c> is a simple botting tool designed to be easy for anyone to use; intended for <cg>showcases</c>.

# Features

 * Basic ClickBot.
 * Practice Fixes.
 * Seed Modifier.
 * Noclip.
 * Show Trajectory.
 * Layout Mode.
 * Speedhack.
 * Frame Stepper.
 * Safe Mode.
 * Renderer.
 * Instant Respawn.
 * No Respawn Flash.
 * No Death Effect.
 * Macro saving and loading system.
 * Macro Auto Saving.

# How to use

* Open the menu using the Open Menu Keybind or the button in the Pause Menu.

* Click the 'Record' toggle in the menu to start recording.

* Finish a practice run of the level.

* Play the macro by clicking the 'Play' toggle in the menu and going into the level.

# Thanks

* Thanks to Viper for letting me use their Safe Mode implementation.

* Thanks to ReplayBot for being open source and letting me steal the code for the renderer.

* Thanks to CatXus and Aadam_yes for helping me test the early android versions.
